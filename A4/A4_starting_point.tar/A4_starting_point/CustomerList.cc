#include <sstream>
#include <iostream>
#include <iomanip>
using namespace std;
#include <string>

#include "CustomerList.h"

CustomerList::CustomerList() : head(0) { }


CustomerList::~CustomerList()
{
  Node *currNode, *nextNode;

  currNode = head;

  while (currNode != 0) {
    nextNode = currNode->next;
    delete currNode->data;
    delete currNode;
    currNode = nextNode;
  }
}

void CustomerList::add(Customer* newCust)
{
  Node *currNode, *prevNode;
  Node* newNode = new Node;
  newNode->data = newCust;
  newNode->next = 0;

  currNode = head;
  prevNode = 0;

  while (currNode != 0) {
    if (newNode->data->getLname() < currNode->data->getLname())
      break;
    prevNode = currNode;
    currNode = currNode->next;
  }

  if (prevNode == 0) {
    head = newNode;
  }
  else {
    prevNode->next = newNode;
  }

  newNode->next = currNode;
}

Customer* CustomerList::get(int id) 
{
  Node *currNode = head;

  while (currNode != 0) {
    if(currNode->data->getId() == id) {
      return currNode->data;
    }
    currNode = currNode->next;
  }

  return 0;
}

int CustomerList::getSize() const {
  Node *currNode = head;
  int size = 0;

  while (currNode != 0) {
    currNode = currNode->next;
    size++;
  }
  
  return size;
}

void CustomerList::toString(string& outStr)
{
  Node* currNode;
  ostringstream output;

  for (Node* currNode=head; currNode != 0; currNode = currNode->next) {
    ostringstream name;
    name << currNode->data->getFname() << " " << currNode->data->getLname();

    output << "Customer ID " << currNode->data->getId() << endl << endl
           << "    Name: " << setw(40) << name.str() << endl 
           << "    Address: " << setw(37) << currNode->data->getAddress() << endl
           << "    Phone Number: " << setw(32) <<  currNode->data->getPhoneNumber() << endl;
    
    if (currNode->data->getNumVehicles() > 0) {
        output << endl << "    " << currNode->data->getNumVehicles() 
                  << " vehicle(s): " << endl << endl;

        string vehicle_output;
        currNode->data->getVehicles().toString(vehicle_output);
        output << vehicle_output << endl<<endl;
    }

  }
    
  outStr = output.str();

}

