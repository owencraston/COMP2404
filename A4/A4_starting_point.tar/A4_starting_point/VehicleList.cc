#include <sstream>
#include <iomanip>
#include <iostream>
using namespace std;
#include <string>

#include "VehicleList.h"

VehicleList::VehicleList() : head(0) { }


VehicleList::~VehicleList()
{
  Node *currNode, *nextNode;

  currNode = head;

  while (currNode != 0) {
    nextNode = currNode->next;
    delete currNode->data;
    delete currNode;
    currNode = nextNode;
  }
}


void VehicleList::add(Vehicle* newVeh)
{
  Node *currNode, *prevNode;
  Node* newNode = new Node;
  newNode->data = newVeh;
  newNode->next = 0;

  currNode = head;
  prevNode = 0;

  while (currNode != 0) {
    if (newNode->data->getYear() > currNode->data->getYear())
      break;
    prevNode = currNode;
    currNode = currNode->next;
  }

  if (prevNode == 0) {
    head = newNode;
  }
  else {
    prevNode->next = newNode;
  }

  newNode->next = currNode;

}

int VehicleList::getSize() const {
  Node *currNode = head;
  int size = 0;

  while (currNode != 0) {
    currNode = currNode->next;
    size++;
  }
  
  return size;
}

void VehicleList::toString(string& outStr)
{
  Node* currNode;

  ostringstream output;

  for (currNode=head; currNode != 0; currNode = currNode->next) {
    ostringstream make_model;
    make_model << currNode->data->getMake() << " " << currNode->data->getModel();

    output << "\t" << setw(7) << currNode->data->getColour() << " " 
                 << currNode->data->getYear() << " " << setw(17) << make_model.str() << " (" 
                 << currNode->data->getMilage() << "km)" << endl;

  }
  
  outStr = output.str();

}

