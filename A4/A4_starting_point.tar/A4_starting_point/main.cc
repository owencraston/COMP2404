#include "ShopController.h"

int main(int argc, char* argv[])
{
  ShopController control;

  control.launch();

  return 0;
}

