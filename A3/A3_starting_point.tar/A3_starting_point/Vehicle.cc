#include "Vehicle.h"

Vehicle::Vehicle(string ma, string mo, string col, int y, int m) { 
    make = ma;
    model = mo;
    colour = col;
    year = y;
    mileage = m;
}

string  Vehicle::getMake()      { return make; }
string  Vehicle::getModel()     { return model; }
string  Vehicle::getColour()    { return colour; }
int     Vehicle::getYear()      { return year; }
int     Vehicle::getMilage()    { return mileage; }

