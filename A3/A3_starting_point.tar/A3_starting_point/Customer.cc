#include <iostream>
using namespace std;
#include "Customer.h"


int Customer::nextId = 1000;

Customer::Customer(string fname, string lname, string add, string pnum) { 
    id          = nextId++;
    firstName   = fname;
    lastName    = lname;
    address     = add;
    phoneNumber = pnum;
}

int           Customer::getId()                 { return id; }
string        Customer::getFname()              { return firstName; }
string        Customer::getLname()              { return lastName; }
string        Customer::getAddress()            { return address; }
string        Customer::getPhoneNumber()        { return phoneNumber; }
int           Customer::getNumVehicles()        { return vehicles.getSize(); }
VehicleArray& Customer::getVehicles()           { return vehicles; }
int           Customer::addVehicle(Vehicle* v)  { return vehicles.add(v); }

